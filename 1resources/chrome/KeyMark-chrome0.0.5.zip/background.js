chrome.browserAction.onClicked.addListener(listener);

function listener() {
  const foo = (storedData) => {
    if (storedData["optionsData"] == null) {
      chrome.storage.sync.set({
        optionsData: {
          activeOptions: ["reddit", "site:wikipedia.com", "quora"],
          passiveOptions: ["", ""],
        },
      });
    }
  };
  let getting = chrome.storage.sync.get(["optionsData"], foo);
  chrome.tabs.create({
    url: chrome.runtime.getURL("settings/settings.html"),
  });
}
